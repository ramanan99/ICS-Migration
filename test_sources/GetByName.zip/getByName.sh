. ./setEnv.sh

cd $NMS_HOME/temp/getByName

export CLASSPATH=$NMS_HOME/classes/NmsServerClasses.jar:$NMS_HOME/classes/jta.jar:$NMS_HOME/classes/hbnlib/ant-antlr-1.6.5.jar:$NMS_HOME/classes/hbnlib/antlr-2.7.6.jar:$NMS_HOME/classes/hbnlib/asm-attrs.jar:$NMS_HOME/classes/hbnlib/asm.jar:$NMS_HOME/classes/hbnlib/c3p0-0.9.1.jar:$NMS_HOME/classes/hbnlib/cglib-2.1.3.jar:$NMS_HOME/classes/hbnlib/commons-collections-2.1.1.jar:$NMS_HOME/classes/hbnlib/commons-logging-1.0.4.jar:$NMS_HOME/classes/hbnlib/dom4j-1.6.1.jar:$NMS_HOME/classes/hbnlib/ehcache-1.2.3.jar:$NMS_HOME/classes/hbnlib/hibernate3.jar::$NMS_HOME/classes/CommonPlatform.jar:$NMS_HOME/classes/CustomizedPlatform.jar:.

javac -cp $CLASSPATH -d . NodeList.java
java -cp $CLASSPATH test.NodeList $1 
